-- Ensure you've run SalesOrdersStructure.sql
-- and SalesOrdersData.sql in the Sample Databases folder
-- in order to run this example. 

USE SalesOrdersSample;
GO

-- Listing 2.15 Sample Index creation SQL
CREATE INDEX CustOrder 
ON Orders(CustomerID, OrderTotal);
