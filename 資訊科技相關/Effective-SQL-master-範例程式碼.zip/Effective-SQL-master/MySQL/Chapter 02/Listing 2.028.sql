-- Listing 2.28 shows how to create an index for case-sensitive RDBMS to allow case-insensitive queries.

-- Because MySQL Server is case-insensitive, there's no need to have this listing.